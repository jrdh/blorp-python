# Blorp-python
Python client implementation for [Blorp](https://github.com/jrdh/blorp).
Uses async-redis, redis and Python's asyncio module.

## Todo
- comments
- tests
